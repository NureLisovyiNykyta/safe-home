import ManageSubscriptionForm from "../../components/manage-subscription-form";
import './index.css';

const ManageSubscriptionPage = () => {


  return (
    <div className="manage-subs-page">
      <ManageSubscriptionForm />
    </div>
  );
};

export default ManageSubscriptionPage;
