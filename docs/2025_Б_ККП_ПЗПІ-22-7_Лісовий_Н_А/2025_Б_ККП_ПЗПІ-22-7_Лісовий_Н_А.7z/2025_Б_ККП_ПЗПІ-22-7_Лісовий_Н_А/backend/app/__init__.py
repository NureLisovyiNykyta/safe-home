from app.app import login_manager, oauth, db, mail, socketio
